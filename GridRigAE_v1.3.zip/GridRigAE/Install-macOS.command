#!/bin/bash
set -euo pipefail
if pgrep -x 'After Effects' >/dev/null; then
  echo 'Close After Effects, then run this installer again.'
  exit 1
fi
gridrig_base="$(cd -- "$(dirname -- "$0")" && pwd)"
gridrig_source="$gridrig_base/com.gridrig.ae"
gridrig_root="$HOME/Library/Application Support/Adobe/CEP"
gridrig_destination="$gridrig_root/extensions/com.gridrig.ae"
if [ ! -f "$gridrig_source/CSXS/manifest.xml" ]; then
  echo 'Extract the entire ZIP first.'
  exit 1
fi
mkdir -p "$gridrig_root/extensions"
gridrig_backup=''
if [ -e "$gridrig_destination" ]; then
  mkdir -p "$gridrig_root/GridRigBackups"
  gridrig_backup="$(mktemp -d "$gridrig_root/GridRigBackups/previous-XXXXXX")/com.gridrig.ae"
  mv "$gridrig_destination" "$gridrig_backup"
fi
if ! ditto "$gridrig_source" "$gridrig_destination"; then
  rm -rf -- "$gridrig_destination"
  if [ -n "$gridrig_backup" ]; then mv "$gridrig_backup" "$gridrig_destination"; fi
  echo 'Installation failed; the previous version was restored if present.'
  exit 1
fi
defaults write com.adobe.CSXS.11 PlayerDebugMode 1
defaults write com.adobe.CSXS.12 PlayerDebugMode 1
echo 'Installed GridRig AE. Enabled unsigned local CEP panels for CSXS 11 and 12.'
echo 'Open After Effects > Window > Extensions > GridRig AE.'
echo 'If the menu does not refresh after restarting AE, sign out of macOS and back in.'
