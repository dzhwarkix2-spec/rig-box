#!/bin/bash
set -euo pipefail
if pgrep -x 'After Effects' >/dev/null; then
  echo 'Close After Effects first.'
  exit 1
fi
rm -rf -- "$HOME/Library/Application Support/Adobe/CEP/extensions/com.gridrig.ae"
echo 'GridRig AE panel removed. Existing project rigs remain usable.'
echo 'Shared CEP debug settings were kept for other unsigned panels.'
