$ErrorActionPreference = 'Stop'
try {
    if (Get-Process -Name AfterFX -ErrorAction SilentlyContinue) { throw 'Close After Effects, then run this installer again.' }
    $source = Join-Path $PSScriptRoot 'com.gridrig.ae'
    if (!(Test-Path (Join-Path $source 'CSXS\manifest.xml'))) { throw 'Extract the entire ZIP before running Install-Windows.cmd.' }
    $root = Join-Path $env:APPDATA 'Adobe\CEP'
    $extensions = Join-Path $root 'extensions'
    $destination = Join-Path $extensions 'com.gridrig.ae'
    New-Item -Path $extensions -ItemType Directory -Force | Out-Null
    $backup = $null
    if (Test-Path $destination) {
        $backup = Join-Path $root ('GridRigBackups\com.gridrig.ae-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
        New-Item -Path (Split-Path $backup) -ItemType Directory -Force | Out-Null
        Move-Item -LiteralPath $destination -Destination $backup
    }
    try { Copy-Item -LiteralPath $source -Destination $destination -Recurse -Force }
    catch {
        if (Test-Path $destination) { Remove-Item -LiteralPath $destination -Recurse -Force }
        if ($backup) { Move-Item -LiteralPath $backup -Destination $destination }
        throw
    }
    # Unsigned local CEP panels require this Adobe per-user development setting.
    foreach ($version in @(11,12)) {
        $key = 'HKCU:\Software\Adobe\CSXS.' + $version
        New-Item -Path $key -Force | Out-Null
        New-ItemProperty -Path $key -Name PlayerDebugMode -Value '1' -PropertyType String -Force | Out-Null
    }
    Write-Host 'Installed GridRig AE.' -ForegroundColor Green
    Write-Host 'Enabled unsigned local CEP panels for CSXS 11 and 12 (current user only).'
    Write-Host 'Open After Effects > Window > Extensions > GridRig AE.'
    Write-Host "Installed at: $destination"
    if ($backup) { Write-Host "Previous version backed up at: $backup" }
    exit 0
} catch { Write-Host $_.Exception.Message -ForegroundColor Red; exit 1 }
