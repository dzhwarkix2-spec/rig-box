/* Optional real-host verification. Creates only a new test comp; existing user content is retained. */
(function(){
    var bundle=File($.fileName).parent.parent;
    var host=File(bundle.fsName+"/com.gridrig.ae/jsx/host.jsx");
    if(!host.exists){alert("Keep this test inside the extracted GridRigAE folder.");return;}
    $.evalFile(host);
    var log=[],comp=null;
    function requireTrue(test,message){if(!test){throw new Error(message);}log.push("PASS: "+message);}
    function action(name,o){var result=GridRig.dispatch(name,o||{});var parsed=eval("("+result+")");if(!parsed.ok){throw new Error(parsed.message);}return parsed;}
    function select(layer){var a=comp.selectedLayers;for(var i=0;i<a.length;i++){a[i].selected=false;}layer.selected=true;}
    function validateExpressions(group){
        for(var i=1;i<=group.numProperties;i++){
            var p=group.property(i);
            if(p.propertyType===PropertyType.PROPERTY){
                if(p.canSetExpression && p.expressionEnabled){p.valueAtTime(comp.time,false);if(p.expressionError){throw new Error(p.name+": "+p.expressionError);}}
            }else{validateExpressions(p);}
        }
    }
    try{
        if(!app.project){app.newProject();}
        comp=app.project.items.addComp("GridRig smoke test "+new Date().getTime(),1920,1080,1,5,30);
        comp.openInViewer();
        var target=comp.layers.addText("AFTER EFFECTS");
        var doc=target.property("ADBE Text Properties").property("ADBE Text Document").value;
        doc.fontSize=100;target.property("ADBE Text Properties").property("ADBE Text Document").setValue(doc);
        target.property("ADBE Transform Group").property("ADBE Position").setValue([500,540]);
        select(target);action("create",{});
        requireTrue(comp.numLayers===3,"creates exactly two rig layers");
        var rig=GridRig.find(comp,target),ctrl=rig.ctrl,gfx=rig.gfx;
        requireTrue(gfx.property("ADBE Root Vectors Group").numProperties===9,"four guides, a bounding box and four corner markers");
        validateExpressions(gfx);log.push("PASS: generated expressions evaluate without errors");
        GridRig.expr(ctrl,"Horizontal Extension").setValue(40);GridRig.expr(ctrl,"Vertical Extension").setValue(40);
        GridRig.expr(ctrl,"Frame Width %").setValue(120);GridRig.expr(ctrl,"Frame Height %").setValue(60);
        validateExpressions(gfx);log.push("PASS: frame resize expressions evaluate");
        GridRig.expr(ctrl,"Guide Opacity").setValue(0);validateExpressions(gfx);
        requireTrue(GridRig.expr(ctrl,"Boundary Opacity").value===100,"boundary remains visible with guides hidden");
        GridRig.expr(ctrl,"Guide Opacity").setValue(45);
        var p=GridRig.expr(ctrl,"Master Reveal");p.setValueAtTime(0,0);p.setValueAtTime(1,100);
        comp.time=0.5;validateExpressions(gfx);
        target.name="Renamed target";ctrl.name="Renamed controller";gfx.name="Renamed graphics";target.moveToBeginning();
        requireTrue(GridRig.targetOf(ctrl)===target,"Layer Controls survive renaming and reordering");
        doc.text="A LONGER TEXT TITLE";target.property("ADBE Text Properties").property("ADBE Text Document").setValue(doc);
        target.property("ADBE Transform Group").property("ADBE Rotate Z").setValue(15);
        validateExpressions(gfx);log.push("PASS: changed text and rotated target evaluate");
        gfx.remove();select(ctrl);action("create");rig=GridRig.find(comp,ctrl);gfx=rig.gfx;
        requireTrue(GridRig.expr(ctrl,"Master Reveal").numKeys===2,"graphics repair preserves reveal keyframes");
        validateExpressions(gfx);
        select(gfx);action("remove");requireTrue(comp.numLayers===1 && comp.layer(1)===target,"removal preserves original target");
        select(target);action("create",{});
        log.push("A fresh default rig remains in the new test composition for visual inspection.");
        alert("GridRig AE smoke test passed.\n\n"+log.join("\n"));
    }catch(e){alert("GridRig AE smoke test stopped.\n\n"+log.join("\n")+"\n\nERROR: "+e.toString()+"\nLine: "+e.line+"\n\nThe test comp is retained for inspection.");}
}());
