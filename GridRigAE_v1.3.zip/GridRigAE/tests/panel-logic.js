/* Minimal DOM harness for panel event/bridge behavior. This is not a render test. */
'use strict';
const vm=require('vm'),fs=require('fs'),path=require('path'),assert=require('assert');
const dir=path.resolve(__dirname,'../com.gridrig.ae');
const ids=[...fs.readFileSync(path.join(dir,'index.html'),'utf8').matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]);
assert.equal(ids.length,new Set(ids).size,'unique HTML IDs');
const boxes=['live'];
const nums=['padding','stroke','horizontal','vertical'];
const values={padding:'16',stroke:'1',color:'#c4c4c4',horizontal:'40',vertical:'40'};
function environment(native=true){
 const els={},events={},store={},queue=[],calls=[];
 ids.forEach(id=>els[id]={id,type:boxes.includes(id)?'checkbox':nums.includes(id)?'number':'',checked:id==='live',value:values[id]||'',hidden:id==='help',disabled:false,textContent:'',listeners:{},addEventListener(e,f){this.listeners[e]=f;},setAttribute(k,v){this[k]=v;}});
 const context={document:{getElementById:id=>{assert(els[id],'element '+id+' exists');return els[id];}},localStorage:{getItem:k=>store[k]||null,setItem:(k,v)=>store[k]=v},setTimeout:f=>queue.push(f),addEventListener:(n,f)=>events[n]=f};
 context.window=context;
 if(native)context.__adobe_cep__={evalScript(code,cb){calls.push(code);queue.push(()=>cb(JSON.stringify(code.includes('"inspect"')?{ok:true,selected:true,label:'Title'}:{ok:true,message:'Done'})));}};
 vm.createContext(context);
 for(const f of ['js/bridge.js','js/app.js'])vm.runInContext(fs.readFileSync(path.join(dir,f),'utf8'),context);
 function flush(){while(queue.length)queue.shift()();}
 function fire(id,event){els[id].listeners[event].call(els[id],{preventDefault(){}});}
 return {els,calls,context,flush,fire,events};
}
let e=environment();e.flush();assert.equal(e.els.target.textContent,'Title');assert(!e.els.create.disabled);
assert(!e.els.settings.open,'setup collapsed by default');
e.fire('rig-form','submit');assert(e.els.create.disabled,'busy state prevents double clicks');e.flush();
assert(e.calls.some(s=>s.includes('"create"')&&s.includes('"padding":16')&&s.includes('"horizontal":40')&&s.includes('"vertical":40')),'creation forwards defaults');
assert(!ids.includes('columns')&&!ids.includes('rows')&&!ids.includes('box'),'no subdivision controls or extra box');
e.els.padding.value='50';e.fire('defaults','click');assert.equal(e.els.padding.value,16);assert(e.els.live.checked);
e.fire('help-toggle','click');assert(!e.els.help.hidden);assert.equal(e.els['help-toggle']['aria-expanded'],'true');
e.fire('controls','click');e.flush();assert(e.calls.some(s=>s.includes('"controls"')));
e.fire('remove','click');e.flush();assert(e.calls.some(s=>s.includes('"remove"')));
e.events.focus();e.fire('rig-form','submit');e.flush();assert.equal(e.els.status.textContent,'Done','focus refresh does not swallow the create click');
e=environment(false);assert(e.els.create.disabled);assert.equal(e.els.target.textContent,'Panel preview');
console.log('PASS panel events, collapsed setup, defaults, validation, help, management, native bridge and focus/click sequencing');
