/* Run with Node.js. Model tests supplement, but do not replace, real AE testing. */
'use strict';
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
const root=path.resolve(__dirname,'../com.gridrig.ae');
function expand(file){return fs.readFileSync(file,'utf8').replace(/^#include "([^"]+)"/gm,(_,p)=>expand(path.resolve(path.dirname(file),p)));}
const host=expand(path.join(root,'jsx/host.jsx'));
for(const file of ['js/app.js','js/bridge.js']) new vm.Script(fs.readFileSync(path.join(root,file),'utf8'),{filename:file});
new vm.Script(host,{filename:'host.jsx'});
let comp,undo=0;
class Prop{
 constructor(name,value=0,owner=null){this.name=name;this._value=value;this.expression='';this.keys=[];this.owner=owner;this.link=null;}
 setValue(v){if(this.owner&&this.owner.matchName==='ADBE Layer Control'){this.link=v>0?comp.layer(v):null;}this._value=v;}
 get value(){if(this.owner&&this.owner.matchName==='ADBE Layer Control')return this.link&&comp._layers.includes(this.link)?this.link.index:0;return this._value;}
 setValueAtTime(t,v){this.keys.push({t,v});this._value=v;}
 get numKeys(){return this.keys.length;}
}
class Group{
 constructor(name,matchName=name){this.name=name;this.matchName=matchName;this.items=[];this.named={};this.parentGroup=null;}
 get numProperties(){return this.items.length;}
 remove(){if(this.parentGroup)this.parentGroup.items.splice(this.parentGroup.items.indexOf(this),1);}
 property(n){
  if(typeof n==='number')return this.items[n-1];
  const found=this.items.find(x=>x.name===n||x.matchName===n);if(found)return found;
  if(!this.named[n])this.named[n]=/Parade|Root Vectors|Transform Group|Vectors Group/.test(n)?new Group(n):new Prop(n);
  return this.named[n];
 }
 addProperty(n){
  const g=new Group(n,n);g.parentGroup=this;
  if(/Control$/.test(n))g.items.push(new Prop('Value',0,g));
  this.items.push(g);return g;
 }
}
class AVLayer{
 constructor(name){this.name=name;this.comment='';this.props={};this.hasVideo=true;this.nullLayer=false;this.adjustmentLayer=false;this.threeDLayer=false;this.parent=null;this.width=1920;this.height=1080;this.inPoint=0;this.outPoint=8;this.selected=false;this.locked=false;this.containingComp=comp;}
 get index(){return comp._layers.indexOf(this)+1;}
 property(n){if(!this.props[n])this.props[n]=new Group(n);return this.props[n];}
 moveBefore(other){comp._layers.splice(comp._layers.indexOf(this),1);comp._layers.splice(comp._layers.indexOf(other),0,this);}
 remove(){comp._layers.splice(comp._layers.indexOf(this),1);}
 sourceRectAtTime(){return this.rect||{left:0,top:0,width:this.width,height:this.height};}
}
class TextLayer extends AVLayer{constructor(name){super(name);this.rect={left:-40,top:-70,width:500,height:90};}}
class ShapeLayer extends AVLayer{}
class CompItem{
 constructor(){this._layers=[];this.duration=8;this.time=0;this.width=1920;this.height=1080;this.layers={addNull:()=>{let l=new AVLayer('Null');l.nullLayer=true;return this.add(l);},addShape:()=>this.add(new ShapeLayer('Shape'))};}
 add(l){this._layers.forEach(x=>x.selected=false);this._layers.unshift(l);l.selected=true;return l;}
 get numLayers(){return this._layers.length;}
 get selectedLayers(){return this._layers.filter(x=>x.selected);}
 layer(i){return this._layers[i-1];}
}
comp=new CompItem();
const context={AVLayer,TextLayer,ShapeLayer,CompItem,Shape:function(){},app:{project:{activeItem:comp},beginUndoGroup(){undo++;},endUndoGroup(){undo--;},executeCommand(){}},Math,Date};
vm.createContext(context);vm.runInContext(host,context);const G=context.GridRig;
const select=l=>{comp._layers.forEach(x=>x.selected=false);l.selected=true;};
const call=(a,o={})=>JSON.parse(G.dispatch(a,o));
let checks=0;function check(name,fn){fn();checks++;console.log('PASS',name);}
const target=comp.add(new TextLayer('دەستپێک "Title" \\ A'));
const initial={name:target.name,comment:target.comment,parent:target.parent};
check('invalid multiple selections do not mutate',()=>{let second=comp.add(new AVLayer('Other'));target.selected=true;assert(!call('create').ok);assert.equal(comp.numLayers,2);second.remove();select(target);});
check('reject 3D parents before mutation',()=>{target.parent={threeDLayer:true};assert(!call('create').ok);assert.equal(comp.numLayers,1);target.parent=null;});
check('one click builds two layers',()=>{assert(call('create').ok);assert.equal(comp.numLayers,3);assert.equal(undo,0);});
let ctrl=comp.selectedLayers[0],gfx=comp._layers.find(l=>G.tag(l)&&G.tag(l).role==='GFX');
check('target preserved; independent parenting and index references',()=>{assert.equal(target.name,initial.name);assert.equal(target.comment,initial.comment);assert.equal(target.parent,initial.parent);assert.equal(ctrl.parent,target);assert.equal(gfx.parent,ctrl);assert.equal(G.targetOf(ctrl),target);});
check('create reuses rig and preserves animation',()=>{G.expr(ctrl,'Master Reveal').setValueAtTime(0,0);G.expr(ctrl,'Master Reveal').setValueAtTime(1,100);select(target);assert(call('create').ok);assert.equal(comp.numLayers,3);assert.equal(G.expr(ctrl,'Master Reveal').numKeys,2);});
check('rename and reorder preserve layer links',()=>{ctrl.name='Custom CTRL';gfx.name='Custom GFX';target.name='Changed';target.moveBefore(gfx);assert.equal(G.targetOf(ctrl),target);select(gfx);assert(call('controls').ok);assert.equal(comp.selectedLayers[0],ctrl);});
// Evaluate generated expressions using geometry-aware expression mocks.
function effectFor(layer){return name=>()=>{const p=G.expr(layer,name);return p.owner&&p.owner.matchName==='ADBE Layer Control'?layerObject(p.link):p.value;};}
function layerObject(layer){return {effect:effectFor(layer),sourceRectAtTime:()=>layer.sourceRectAtTime()};}
let matrix=[1,0,0,1,500,400];
const thisLayer={
 toComp(p){const[a,b,c,d,tx,ty]=matrix;return[a*p[0]+c*p[1]+tx,b*p[0]+d*p[1]+ty];},
 fromComp(p){const[a,b,c,d,tx,ty]=matrix,det=a*d-b*c;return[(d*(p[0]-tx)-c*(p[1]-ty))/det,(-b*(p[0]-tx)+a*(p[1]-ty))/det];}
};
function evaluate(e){return vm.runInNewContext(e,{effect:effectFor(gfx),thisLayer,thisComp:comp,time:comp.time,Math,createPath:(points,inTangents,outTangents,closed)=>({points,closed})});}
function near(a,b){assert(Math.abs(a-b)<1e-6,`${a} != ${b}`);}
check('all generated expressions evaluate to finite output',()=>{
 let count=0;
 function walk(g){if(g.expression){let value=evaluate(g.expression);assert(value!==undefined);const numbers=value.points?value.points.flat():Array.isArray(value)?value:[value];numbers.forEach(x=>assert(Number.isFinite(x)));count++;}
  if(g.items)g.items.forEach(walk);if(g.named)Object.values(g.named).forEach(walk);}
 Object.values(gfx.props).forEach(walk);assert.equal(count,42);console.log(' evaluated',count,'expressions');
});
check('default guides stop 40 pixels beyond the box, not at comp edges',()=>{
 const box=evaluate(G.boxPathExpression()).points;
 const left=evaluate(G.pathExpression('Left')).points,top=evaluate(G.pathExpression('Top')).points;
 near(left[0][1],box[0][1]-40);near(left[1][1],box[3][1]+40);
 near(top[0][0],box[0][0]-40);near(top[1][0],box[1][0]+40);
 assert(thisLayer.toComp(left[0])[1]>0&&thisLayer.toComp(left[1])[1]<1080);
});
check('extension sliders resize each axis independently',()=>{
 const box=evaluate(G.boxPathExpression()).points;
 G.expr(ctrl,'Horizontal Extension').setValue(120);G.expr(ctrl,'Vertical Extension').setValue(10);
 let top=evaluate(G.pathExpression('Top')).points,left=evaluate(G.pathExpression('Left')).points;
 near(top[0][0],box[0][0]-120);near(top[1][0],box[1][0]+120);
 near(left[0][1],box[0][1]-10);near(left[1][1],box[3][1]+10);
 G.expr(ctrl,'Horizontal Extension').setValue(0);top=evaluate(G.pathExpression('Top')).points;near(top[0][0],box[0][0]);near(top[1][0],box[1][0]);
 G.expr(ctrl,'Horizontal Extension').setValue(40);G.expr(ctrl,'Vertical Extension').setValue(40);
});
check('changing comp dimensions does not stretch the lines',()=>{
 const before=JSON.stringify(evaluate(G.pathExpression('Top')).points);
 const ow=comp.width,oh=comp.height;comp.width=3840;comp.height=2160;
 assert.equal(JSON.stringify(evaluate(G.pathExpression('Top')).points),before);comp.width=ow;comp.height=oh;
});
check('live bounds and frozen bounds align the vertical guides',()=>{
 let p=evaluate(G.pathExpression('Left')).points;near(p[0][0],-56);
 target.rect.width=750;p=evaluate(G.pathExpression('Right')).points;near(p[0][0],726);
 G.expr(ctrl,'Live Bounds').setValue(0);p=evaluate(G.pathExpression('Right')).points;near(p[0][0],476);
 G.expr(ctrl,'Live Bounds').setValue(1);
});
check('frame sizing retains the chosen short extension lengths',()=>{
 const before=evaluate(G.pathExpression('Right')).points[0][0]-evaluate(G.pathExpression('Left')).points[0][0];
 G.expr(ctrl,'Frame Width %').setValue(50);G.expr(ctrl,'Frame Height %').setValue(200);
 const left=evaluate(G.pathExpression('Left')).points,right=evaluate(G.pathExpression('Right')).points;
 near(right[0][0]-left[0][0],before/2);
 near(left[1][1]-left[0][1],244+80);
 const top=evaluate(G.pathExpression('Top')).points,bottom=evaluate(G.pathExpression('Bottom')).points;
 near(bottom[0][1]-top[0][1],244);
 near(top[1][0]-top[0][0],before/2+80);
 G.expr(ctrl,'Frame Width %').setValue(100);G.expr(ctrl,'Frame Height %').setValue(100);
});
check('four guide lines plus a real bounding box and four corner markers',()=>{
 const groups=gfx.property('ADBE Root Vectors Group').items;
 assert.deepEqual(groups.map(g=>g.name),['Guide Left','Guide Right','Guide Top','Guide Bottom','Bounding Box','Corner Top Left','Corner Top Right','Corner Bottom Right','Corner Bottom Left']);
 assert(!ctrl.property('ADBE Effect Parade').items.some(g=>/Grid Columns|Grid Rows|Box Opacity/.test(g.name)));
});
check('boundary is a closed rectangle with corners on guide intersections',()=>{
 const box=evaluate(G.boxPathExpression());assert(box.closed);assert.equal(box.points.length,4);
 const l=evaluate(G.pathExpression('Left')).points,r=evaluate(G.pathExpression('Right')).points;
 const t=evaluate(G.pathExpression('Top')).points,b=evaluate(G.pathExpression('Bottom')).points;
 const expected=[[l[0][0],t[0][1]],[r[0][0],t[0][1]],[r[0][0],b[0][1]],[l[0][0],b[0][1]]];
 box.points.forEach((p,i)=>{near(p[0],expected[i][0]);near(p[1],expected[i][1]);});
 for(let i=0;i<4;i++){let q=evaluate(G.cornerPathExpression(i));assert(q.closed);near((q.points[0][0]+q.points[2][0])/2,box.points[i][0]);near((q.points[0][1]+q.points[2][1])/2,box.points[i][1]);}
});
check('box stays visible with guides hidden and has independent reveal',()=>{
 G.expr(ctrl,'Guide Opacity').setValue(0);near(evaluate(G.opacityExpression()),0);
 assert.equal(G.expr(ctrl,'Boundary Opacity').value,100);near(evaluate(G.trimExpression('Boundary',true)),100);
 G.expr(ctrl,'Boundary - End').setValue(25);near(evaluate(G.trimExpression('Boundary',true)),25);
 near(evaluate(G.trimExpression('Guide Top',true)),100);
 G.expr(ctrl,'Boundary - End').setValue(100);G.expr(ctrl,'Guide Opacity').setValue(45);
});
check('master reveal multiplies the individual reveal interval',()=>{
 G.expr(ctrl,'Guide Left - Start').setValue(20);G.expr(ctrl,'Guide Left - End').setValue(80);G.expr(ctrl,'Master Reveal').setValue(50);
 near(evaluate(G.trimExpression('Guide Left',false)),20);near(evaluate(G.trimExpression('Guide Left',true)),50);
 G.expr(ctrl,'Master Reveal').setValue(0);near(evaluate(G.trimExpression('Guide Left',true)),20);G.expr(ctrl,'Master Reveal').setValue(100);
});
check('repair preserves existing controller keyframes',()=>{gfx.remove();select(ctrl);assert(call('create').ok);assert.equal(comp.numLayers,3);assert.equal(G.expr(ctrl,'Master Reveal').numKeys,2);gfx=comp._layers.find(l=>G.tag(l)&&G.tag(l).role==='GFX');});
check('duplicate tags block removal without deleting anything',()=>{const duplicate=comp.add(new AVLayer('Duplicate'));duplicate.comment=ctrl.comment;select(ctrl);assert(!call('remove').ok);assert.equal(comp.numLayers,4);duplicate.remove();});
check('remove is scoped to owned layers',()=>{const unrelated=comp.add(new AVLayer('GridRig CTRL — impostor'));select(gfx);assert(call('remove').ok);assert.equal(comp.numLayers,2);assert(comp._layers.includes(target));assert(comp._layers.includes(unrelated));assert.equal(undo,0);unrelated.remove();});
check('empty bounds reject before mutation',()=>{select(target);target.rect.width=0;assert(!call('create').ok);assert.equal(comp.numLayers,1);target.rect.width=500;});
check('partial creation errors roll back owned layers',()=>{select(target);const real=G.graphics;G.graphics=function(){throw new Error('Injected creation failure');};assert(!call('create').ok);assert.equal(comp.numLayers,1);assert.equal(undo,0);G.graphics=real;});
check('version 1 upgrade keeps guide keys and restores boundary and corners alongside four guides',()=>{
 select(target);assert(call('create').ok);ctrl=comp.selectedLayers[0];gfx=comp._layers.find(l=>G.tag(l)&&G.tag(l).role==='GFX');
 const id=G.tag(ctrl).id;
 G.expr(ctrl,'Guide Left - End').setValueAtTime(0,0);G.expr(ctrl,'Guide Left - End').setValueAtTime(1,100);
 ctrl.property('ADBE Effect Parade').property('Frame Width %').remove();ctrl.property('ADBE Effect Parade').property('Frame Height %').remove();
 G.slider(ctrl,'Grid Columns',6);G.slider(ctrl,'Box Opacity',100);
 ctrl.comment='GRIDRIG_AE|1|'+id+'|CTRL|1,1,0,0,-40,-70,500,90';gfx.comment='GRIDRIG_AE|1|'+id+'|GFX|';
 gfx.property('ADBE Root Vectors Group').addProperty('ADBE Vector Group').name='Old Box';
 const old=gfx;select(ctrl);assert(call('create').ok);gfx=comp._layers.find(l=>G.tag(l)&&G.tag(l).role==='GFX');
 assert(!comp._layers.includes(old));assert.equal(comp.numLayers,3);assert.equal(gfx.property('ADBE Root Vectors Group').numProperties,9);
 assert.equal(G.expr(ctrl,'Guide Left - End').numKeys,2);assert.equal(G.tag(ctrl).version,4);assert.equal(G.expr(ctrl,'Frame Width %').value,100);
});
check('version 1.1 four-line rig upgrades to include boundary and preserves keys',()=>{
 const id=G.tag(ctrl).id;ctrl.comment='GRIDRIG_AE|2|'+id+'|CTRL|-40,-70,500,90';gfx.comment='GRIDRIG_AE|2|'+id+'|GFX|';
 const effects=ctrl.property('ADBE Effect Parade');
 ['Boundary Color','Boundary Width','Boundary Opacity','Boundary - Start','Boundary - End','Corner Size','Corner Opacity'].forEach(n=>effects.property(n).remove());
 const root=gfx.property('ADBE Root Vectors Group');while(root.numProperties>4)root.property(root.numProperties).remove();
 select(ctrl);assert(call('create').ok);gfx=comp._layers.find(l=>G.tag(l)&&G.tag(l).role==='GFX');
 assert.equal(G.tag(ctrl).version,4);assert.equal(gfx.property('ADBE Root Vectors Group').numProperties,9);assert.equal(G.expr(ctrl,'Guide Left - End').numKeys,2);
 assert.equal(G.expr(ctrl,'Boundary Opacity').value,100);
});
check('version 1.2 upgrades to short lines without losing box or guide keyframes',()=>{
 const id=G.tag(ctrl).id;ctrl.comment='GRIDRIG_AE|3|'+id+'|CTRL|-40,-70,500,90';gfx.comment='GRIDRIG_AE|3|'+id+'|GFX|';
 const effects=ctrl.property('ADBE Effect Parade');effects.property('Horizontal Extension').remove();effects.property('Vertical Extension').remove();
 G.expr(ctrl,'Boundary - End').setValueAtTime(0,0);G.expr(ctrl,'Boundary - End').setValueAtTime(1,100);
 select(ctrl);assert(call('create').ok);gfx=comp._layers.find(l=>G.tag(l)&&G.tag(l).role==='GFX');
 assert.equal(G.tag(ctrl).version,4);assert.equal(G.expr(ctrl,'Horizontal Extension').value,40);assert.equal(G.expr(ctrl,'Vertical Extension').value,40);
 assert.equal(G.expr(ctrl,'Boundary - End').numKeys,2);assert.equal(G.expr(ctrl,'Guide Left - End').numKeys,2);
});
check('failed upgrade leaves original graphics and effects intact',()=>{
 const id=G.tag(ctrl).id;ctrl.comment='GRIDRIG_AE|1|'+id+'|CTRL|1,1,0,0,-40,-70,500,90';
 ctrl.property('ADBE Effect Parade').property('Frame Width %').remove();
 const originalCount=ctrl.property('ADBE Effect Parade').numProperties,real=G.graphics;G.graphics=()=>{throw new Error('Injected upgrade failure');};
 select(ctrl);assert(!call('create').ok);assert.equal(G.tag(ctrl).version,1);assert.equal(ctrl.property('ADBE Effect Parade').numProperties,originalCount);assert(comp._layers.includes(gfx));assert.equal(comp.numLayers,3);assert.equal(undo,0);G.graphics=real;
 assert(call('create').ok);gfx=comp._layers.find(l=>G.tag(l)&&G.tag(l).role==='GFX');
});
check('safe JSON serialization preserves unicode and escapes',()=>{const s='دەستپێک "quote"\\line\n\t\u2028';assert.equal(JSON.parse(G.json({s})).s,s);});
console.log('\n'+checks+' checks passed. AE runtime still requires the supplied host-side smoke test.');
