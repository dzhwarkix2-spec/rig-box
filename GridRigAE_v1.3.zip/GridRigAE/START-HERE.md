# GridRig AE 1.3 — Short guides + bounding box

This version creates **two horizontal guides, two vertical guides, a separate closed bounding box, and four square corner markers**. The guides extend only a short distance past the rectangle, like a compact hash-shaped frame. The default extension is 40 local pixels at each end. The rectangle frames the selected text or artwork. No glow or subdivisions are added.

## Install or update

1. Extract the entire ZIP.
2. Close After Effects.
3. Windows: run **Install-Windows.cmd**. macOS: run **Install-macOS.command**.
4. Open **Window → Extensions → GridRig AE** (sometimes called Extensions (Legacy)).

The installer replaces the earlier panel and backs up its installation outside the extensions directory. This is an unsigned CEP bundle. It enables Adobe's per-user PlayerDebugMode for CEP 11 and 12; no administrator access or downloads are needed.

## Use

Select a 2D text or artwork layer → **Create Rig** → animate in AE's **Effect Controls**.

There is only one construction action. Appearance settings are collapsed. Horizontal Extension and Vertical Extension can also be set there before creation. The panel diagram shows the guides, outlined box and four corner markers. The generated rig contains one controller and one graphics layer. Its Contents contains four Guide groups, Bounding Box and four Corner groups.

The two vertical lines mark the left and right edges of the artwork. The two horizontal lines mark its top and bottom edges. The guide ends extend past the box by an adjustable amount. They are not tied to the composition edges. A separate closed rectangular path sits between those guides. It is brighter and thicker by default, with independent color, width, opacity and reveal controls. The corner markers follow the same frame. Set Guide Opacity to 0 to see the box independently.

For a title and a button together, place them in a tightly cropped precomp and select that precomp. Selecting a full-frame video initially uses its full source bounds. To make a small frame over a video, lower Frame Width % and Frame Height % in Effect Controls; for example, start at 25% for each, then adjust. The extension sliders control the short overhangs independently. Selecting text or a tightly cropped artwork layer fits the frame to that content.

## Animate using normal AE keyframes

- **Master Reveal:** keyframe 0 → 100 to draw all four lines.
- **Guide Left / Right / Top / Bottom - Start / End:** independently trim each line from 0–100%. Vertical paths run top to bottom; horizontal paths run left to right.
- **Frame Width % / Frame Height %:** change the spacing between the two vertical or two horizontal lines. 100 is the source bounds plus padding. These keep the frame centered while keeping the chosen extension lengths.
- **Horizontal Extension:** pixels beyond the left and right box edges for each horizontal line. Default 40.
- **Vertical Extension:** pixels beyond the top and bottom box edges for each vertical line. Default 40.
- **Guide Offset:** equal padding outside the source rectangle, in local pixels.
- **Stroke Width / Stroke Color / Guide Opacity:** appearance of the four guide lines only.
- **Boundary Width / Boundary Color / Boundary Opacity:** appearance of the separate rectangle. Default: 2 px, white, 100% opacity.
- **Boundary - Start / Boundary - End:** draws or erases the closed rectangle independently, starting at the top-left corner and going clockwise.
- **Corner Size / Corner Opacity:** size and visibility of the four square markers. Markers use Boundary Color. They follow the frame and fade with Master Reveal; they are visual markers, not draggable handles.
- **Live Bounds:** follows changing text and basic shape bounds. Turning it off uses the bounds captured when the rig was created.
- **Controller → Transform → Position:** moves the frame relative to the artwork. Animate the original artwork to move it and the rig together.

Use the stopwatch, Easy Ease and the Graph Editor normally. The panel does not insert animation keyframes.

## Update an earlier version

After updating the extension, select the original layer, controller or graphics from v1.0, v1.1 or v1.2 and click **Create Rig**. This rebuilds the graphics with four short guides, a real bounding box and four corner markers. The existing controller and its guide/reveal keyframes remain. Missing boundary, corner and line-extension controls are added automatically.

Older Box / Grid / Inner / Center / Guide Extension effects remain on upgraded controllers to preserve their stored keys; they are inactive. Use the new **Boundary** controls for the rectangle. New rigs omit the obsolete controls. Custom effects and manual animation placed directly on the old graphics layer are not copied when it is rebuilt; Undo restores the previous rig. Controller animation is retained.

On an already corrected rig, Create Rig simply selects its controller. If its graphics layer was deleted, Create Rig repairs it using the same controller.

## Remove

Select a rig or its original layer, then **Remove Rig**. Only the tagged generated layers are removed. The original layer stays. **Ctrl/Cmd+Z** restores the operation.

Layer references use AE Layer Controls, so renaming and reordering layers are supported. Do not duplicate only the controller or only the graphics layer; create a new rig for another target or duplicate the entire composition.

## Supported scope

Designed for AE 18.4+ hosts that support CEP 11/12. Text, shape, image, solid and precomp layers must be 2D, with a 2D parent chain. Rotating the target rotates the frame and its two pairs of lines. Width is in local pixels, so stroke thickness inherits target/parent scale. 3D layers should be flattened into a 2D precomp first.

Text and shapes use `sourceRectAtTime(time, false)`. This is source geometry before masks/effects; some strokes, text animators, repeaters and other shape operators may not match visible pixels precisely. Images/footage/precomps use the full source rectangle, including transparent margins. Crop tightly when needed.

The generated lines render in exports. For preview-only graphics, enable **Layer → Guide Layer** on the graphics layer. Target opacity is not inherited by parenting; fade Guide Opacity as needed. Target in/out points are copied at creation.

## Validation

Local geometry, lifecycle, migration and panel-logic checks are included. This build has not been run inside After Effects here. Browser-rendered visual inspection and Windows/macOS installer execution are also unverified.

Optional actual-host test: **File → Scripts → Run Script File… → tests/AE-Smoke-Test.jsx**. It creates a separate test composition and preserves existing project content. Save your project first.

## Troubleshooting / manual install

Copy the **com.gridrig.ae** folder, containing CSXS/manifest.xml, into:

- Windows: `%APPDATA%\Adobe\CEP\extensions\`
- macOS: `~/Library/Application Support/Adobe/CEP/extensions/`

This unsigned bundle needs PlayerDebugMode for the installed CEP version. The included installers enable 11 and 12. Fully restart AE if the panel does not appear. Avoid nesting the extension folder inside a second folder with the same name. On managed machines, follow your organization's extension policy.

Opening index.html in an ordinary browser shows a visual preview only. The panel must run inside After Effects to create layers.

If macOS does not launch the command file, open Terminal, type `bash `, drag Install-macOS.command into Terminal and press Return.

Uninstall files remove the panel. Existing project rigs continue working. Shared CEP debug settings and previous-version backups are retained.

## References

- Adobe CEP cookbook: https://github.com/Adobe-CEP/CEP-Resources/blob/master/CEP_12.x/Documentation/CEP%2012%20HTML%20Extension%20Cookbook.md
- Adobe expression reference: https://helpx.adobe.com/after-effects/desktop/work-with-expressions/expression-language-reference/expression-language-reference.html

Original implementation based on the supplied reference images. No proprietary plugin source is included.
