@echo off
setlocal
echo GridRig AE - per-user installer
echo Close After Effects before continuing.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Windows.ps1"
if errorlevel 1 echo Installation did not finish. Read the message above.
pause
