$ErrorActionPreference = 'Stop'
try {
    if (Get-Process -Name AfterFX -ErrorAction SilentlyContinue) { throw 'Close After Effects first.' }
    $destination = Join-Path $env:APPDATA 'Adobe\CEP\extensions\com.gridrig.ae'
    if (Test-Path $destination) { Remove-Item -LiteralPath $destination -Recurse -Force }
    Write-Host 'GridRig AE panel removed. Existing project rigs remain usable.'
    Write-Host 'Shared CEP debug settings were kept, so other unsigned panels continue to work.'
} catch { Write-Host $_.Exception.Message -ForegroundColor Red; exit 1 }
